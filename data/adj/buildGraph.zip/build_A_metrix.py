import torch

import src.utils
import argparse
import numpy as np
from src.utils import bool_flag

parser = argparse.ArgumentParser(description='Unsupervised training')
parser.add_argument("--src_emb", type=str, default=r"D:\coding\Xiong\FMGAN\data\\wiki.en.vec", help="Reload source embeddings")
parser.add_argument("--src_lang", type=str, default='en', help="Source language")
parser.add_argument("--emb_dim", type=int, default=300, help="Embedding dimension")
parser.add_argument("--cuda", type=bool_flag, default=True, help="Run on GPU")
parser.add_argument("--max_vocab", type=int, default=-1, help="Maximum vocabulary size (-1 to disable)")
parser.add_argument("--computable_vocab", type=int, default=-1, help="Maximum vocabulary size (-1 to disable)")

# parse parameters
params = parser.parse_args()

def build_graph(params, K):
    src_dico, _src_emb = src.utils.read_txt_embeddings(params, source=True, full_vocab=False)
    _src_emb = _src_emb
    _src_emb = _src_emb / _src_emb.norm(2, 1, keepdim=True).expand_as(_src_emb)
    # build adjacent matrix
    bs = 32
    _src_emb_T = _src_emb.T
    print(_src_emb_T.size())
    top_value = [] # torch.empty((0,params.max_vocab))
    top_idx   = []
    for i in range(0, _src_emb.size(0), bs):
        print(i )
        a = _src_emb[i:i+bs]
        b = _src_emb[:params.computable_vocab]
        aa = torch.pow(a,2).sum(1,keepdim=True).expand(a.size(0),b.size(0))
        bb = torch.pow(b, 2).sum(1, keepdim=True).expand( b.size(0),a.size(0)).t()
        distance = aa + bb
        distance = distance.addmm_(1,-2,a,b.t())
        distance = distance.clamp(min=1e-12).sqrt()

        bs_top_value, bs_top_idx = distance.topk(K, 1, False, True)
        #

        bs_top_value = -(torch.log(bs_top_value))


        top_value.append(bs_top_value)
        top_idx.append(bs_top_idx)

    top_value = torch.cat(top_value, axis=0)
    top_value = top_value/top_value.norm(1,1,keepdim=True)
    top_idx = torch.cat(top_idx, axis=0)

    col = top_idx.flatten()
    row = torch.arange(params.max_vocab)
    row = torch.repeat_interleave(row, K, dim=-1)
    row = row.cuda() if params.cuda else row
    value = top_value.flatten()
    print("test",value)
    coo = torch.stack([row,col],dim=0)
    print("coo,",coo)
    print(coo.shape)
    print("value shape",value.shape)



    # tmp = top_idx[src_dico.word2id["hello"]]
    # for i in tmp:
    #     print(src_dico.id2word[i.item()])
    #
    # print(coo[:, src_dico.word2id["hello"]*K : src_dico.word2id["hello"]*K+K])
    # print(value[src_dico.word2id["hello"]*K : src_dico.word2id["hello"]*K+K])

    adj = torch.sparse_coo_tensor(coo, value,(params.max_vocab, params.max_vocab))
    # adj = adj + adj.T.multiply(adj.T > adj) - adj.multiply(adj.T > adj)


    return adj


A_matrix = build_graph(params,50)

torch.save(A_matrix, "./ouputs/A_all_n50_matrix")







